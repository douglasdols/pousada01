# Paraty Pousada Boutique v1.1.0

Site responsivo e reservas persistidas no Supabase PostgreSQL, com Supabase Auth para administradores.

## Instalação

1. Crie um **novo projeto Supabase dedicado à pousada**. Não reutilize um banco de produção de outra aplicação.
2. No **SQL Editor** do novo projeto, execute `sql/001_schema.sql` integralmente. Ele cria `pb_rooms`, `pb_bookings`, `pb_admins`, políticas de acesso e duas funções RPC transacionais. As três acomodações inseridas são **exemplos fictícios**.
3. No painel **Authentication > Users**, crie o usuário administrativo com e-mail e senha. Copie o UUID do usuário e execute no SQL Editor: `insert into public.pb_admins(user_id) values ('UUID_DO_USUARIO');`.
4. Copie `.env.example` para `.env`. Preencha `SUPABASE_URL`, `SUPABASE_PUBLISHABLE_KEY` e `SUPABASE_SECRET_KEY` com os valores do **mesmo projeto**. A secret key só deve ficar no backend, nunca no HTML ou JavaScript do navegador.
5. Inicie com Node.js 20 ou superior: `npm run dev` (lê `.env`) ou configure variáveis de ambiente no host e execute `npm start`.
6. Abra `http://localhost:3000` e `http://localhost:3000/admin.html`.

## Implantação

O projeto usa um servidor Node.js para proteger a secret key e executar a API. **Cloudflare Pages estático, isoladamente, não executa `server.js`.** Hospede o backend Node em serviço compatível, ou adapte `/api` para Cloudflare Workers com secrets e mantenha o frontend no Pages. Configure HTTPS, domínio, proteção contra bots, limites de requisição, logs e política de privacidade antes de abrir ao público.

## Segurança e reservas

- As tabelas têm RLS habilitado, sem acesso direto para `anon` e `authenticated`. A secret key fica somente no servidor.
- Login administrativo usa Supabase Auth e o servidor confere associação em `pb_admins`. A sessão fica apenas na memória da aba, sem `localStorage`.
- Criação e reativação de reservas usam funções PostgreSQL com bloqueio transacional por acomodação. Reservas pendentes e confirmadas ocupam disponibilidade.
- Tarifas e unidades são gerenciáveis no painel. **Reduzir unidades abaixo da ocupação existente não cancela reservas já registradas**.
- Não há pagamentos, e-mail transacional, comprovante fiscal, cancelamento pelo hóspede nem confirmação automática. `pending` significa solicitação, não confirmação de hospedagem.
- As datas são interpretadas pelo calendário da pousada, fuso America/Sao_Paulo.
- Não publique os dados demonstrativos, preços, imagens, endereço, telefone ou alegações históricas como fatos verificados.
- Dados pessoais de hóspedes requerem política de privacidade, retenção e procedimentos LGPD antes de produção.

## Testes

`npm test` verifica validações locais. Testes de integração com banco Supabase real e testes visuais em browsers precisam ser feitos após configurar credenciais. **Nenhum projeto Supabase foi alterado automaticamente por este pacote.**

## Changelog

### 1.1.0
- Supabase PostgreSQL em lugar do arquivo JSON local.
- RPCs com bloqueio transacional para criação de reservas e reativação segura.
- Supabase Auth com autorização administrativa por tabela de usuários.
- Gestão de preços, unidades e ativação de acomodações.
- Configuração por variáveis de ambiente e SQL de implantação.
- Testes locais de validação e layout responsivo preservado.
