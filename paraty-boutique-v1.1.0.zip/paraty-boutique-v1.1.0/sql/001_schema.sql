-- Paraty Pousada Boutique v1.1.0 | execute in a NEW dedicated Supabase project
create table if not exists public.pb_rooms (
 id text primary key, name text not null, type text not null, description text not null default '',
 capacity integer not null check(capacity between 1 and 20), units integer not null check(units between 0 and 100),
 price numeric(12,2) not null check(price>=0), amenities text[] not null default '{}',
 image text not null default '', active boolean not null default true, created_at timestamptz not null default now()
);
create table if not exists public.pb_bookings (
 id text primary key, room_id text not null references public.pb_rooms(id), room_name text not null,
 checkin date not null, checkout date not null, nights integer not null check(nights between 1 and 30),
 guests integer not null check(guests between 1 and 20), name text not null, email text not null,
 phone text not null, notes text not null default '', total numeric(12,2) not null,
 status text not null default 'pending' check(status in ('pending','confirmed','cancelled')),
 created_at timestamptz not null default now(), updated_at timestamptz not null default now(),
 constraint pb_booking_dates check(checkout>checkin)
);
create index if not exists pb_bookings_room_dates on public.pb_bookings(room_id,checkin,checkout) where status in ('pending','confirmed');
create table if not exists public.pb_admins (user_id uuid primary key references auth.users(id) on delete cascade);
alter table public.pb_rooms enable row level security;
alter table public.pb_bookings enable row level security;
alter table public.pb_admins enable row level security;
revoke all on public.pb_rooms,public.pb_bookings,public.pb_admins from anon,authenticated;
-- All public booking traffic goes through the application server. No client has direct table access.
create or replace function public.pb_create_booking(
 p_room_id text,p_checkin date,p_checkout date,p_guests integer,p_name text,p_email text,p_phone text,p_notes text
) returns jsonb language plpgsql security definer set search_path = '' as $$
declare r public.pb_rooms%rowtype; occupied integer; nights_count integer; booking_id text;
begin
 if p_checkin is null or p_checkout is null or p_checkin < (now() at time zone 'America/Sao_Paulo')::date
    or p_checkout <= p_checkin or p_checkout > p_checkin + 30 then
   raise exception 'Datas inválidas' using errcode='22023';
 end if;
 perform pg_advisory_xact_lock(hashtextextended(p_room_id, 451));
 select * into r from public.pb_rooms where id=p_room_id and active=true;
 if not found then raise exception 'Acomodação indisponível' using errcode='22023'; end if;
 if p_guests is null or p_guests<1 or p_guests>r.capacity then raise exception 'Quantidade de hóspedes inválida' using errcode='22023'; end if;
 if length(trim(coalesce(p_name,'')))<3 or length(coalesce(p_name,''))>200
   or length(coalesce(p_email,''))>200 or p_email !~ '^[^[:space:]@]+@[^[:space:]@]+\.[^[:space:]@]+$'
   or length(coalesce(p_phone,''))>50 or length(regexp_replace(coalesce(p_phone,''),'\D','','g'))<10
   or length(coalesce(p_notes,''))>200 then raise exception 'Dados do hóspede inválidos' using errcode='22023'; end if;
 select count(*) into occupied from public.pb_bookings b where b.room_id=r.id and b.status in ('pending','confirmed')
 and b.checkin<p_checkout and p_checkin<b.checkout;
 if occupied>=r.units then raise exception 'Sem disponibilidade para este período' using errcode='P0001'; end if;
 nights_count:=p_checkout-p_checkin;
 booking_id:='PB-'||to_char(now(),'YYYY')||'-'||upper(substr(replace(gen_random_uuid()::text,'-',''),1,12));
 insert into public.pb_bookings(id,room_id,room_name,checkin,checkout,nights,guests,name,email,phone,notes,total)
 values(booking_id,r.id,r.name,p_checkin,p_checkout,nights_count,p_guests,trim(p_name),trim(p_email),trim(p_phone),coalesce(p_notes,''),nights_count*r.price);
 return jsonb_build_object('id',booking_id,'status','pending','roomName',r.name,'checkin',p_checkin,'checkout',p_checkout,'total',nights_count*r.price,'message','Solicitação registrada. Aguarde confirmação da pousada.');
end; $$;
revoke all on function public.pb_create_booking(text,date,date,integer,text,text,text,text) from public,anon,authenticated;
grant execute on function public.pb_create_booking(text,date,date,integer,text,text,text,text) to service_role;
create or replace function public.pb_set_booking_status(p_id text,p_status text)
returns jsonb language plpgsql security definer set search_path = '' as $$
declare b public.pb_bookings%rowtype; r public.pb_rooms%rowtype; occupied integer;
begin
 if p_status not in ('pending','confirmed','cancelled') then raise exception 'Status inválido' using errcode='22023'; end if;
 select * into b from public.pb_bookings where id=p_id;
 if not found then raise exception 'Reserva não encontrada' using errcode='P0002'; end if;
 perform pg_advisory_xact_lock(hashtextextended(b.room_id,451));
 select * into b from public.pb_bookings where id=p_id for update;
 if b.status='cancelled' and p_status in ('pending','confirmed') then
   select * into r from public.pb_rooms where id=b.room_id;
   select count(*) into occupied from public.pb_bookings x where x.room_id=b.room_id and x.id<>b.id
     and x.status in ('pending','confirmed') and x.checkin<b.checkout and b.checkin<x.checkout;
   if occupied>=r.units then raise exception 'Sem disponibilidade para reativação' using errcode='P0001'; end if;
 end if;
 update public.pb_bookings set status=p_status,updated_at=now() where id=p_id;
 return jsonb_build_object('id',p_id,'status',p_status);
end; $$;
revoke all on function public.pb_set_booking_status(text,text) from public,anon,authenticated;
grant execute on function public.pb_set_booking_status(text,text) to service_role;

-- DEMONSTRATION ACCOMMODATIONS: replace before production
insert into public.pb_rooms (id,name,type,description,capacity,units,price,amenities,image) values ('imperial','Suíte Imperial Solar','Suíte','Ambiente amplo, atmosfera colonial e detalhes acolhedores.',2,2,980,ARRAY['Cama de casal','Ar-condicionado','Wi-Fi','Banheiro privativo'],'https://images.unsplash.com/photo-1611892440504-42a792e24d32?w=1100&q=85') on conflict (id) do nothing;
insert into public.pb_rooms (id,name,type,description,capacity,units,price,amenities,image) values ('jardim','Chalé Jardim Secreto','Chalé','Um refúgio tranquilo inspirado nos jardins e na natureza de Paraty.',3,2,790,ARRAY['Vista para o jardim','Ar-condicionado','Wi-Fi','Banheiro privativo'],'https://images.unsplash.com/photo-1590490360182-c33d57733427?w=1100&q=85') on conflict (id) do nothing;
insert into public.pb_rooms (id,name,type,description,capacity,units,price,amenities,image) values ('mestre','Apartamento Mestre Paraty','Apartamento','Conforto contemporâneo com referências à arquitetura histórica da cidade.',4,3,650,ARRAY['Até 4 hóspedes','Ar-condicionado','Wi-Fi','Banheiro privativo'],'https://images.unsplash.com/photo-1618773928121-c32242e63f39?w=1100&q=85') on conflict (id) do nothing;
